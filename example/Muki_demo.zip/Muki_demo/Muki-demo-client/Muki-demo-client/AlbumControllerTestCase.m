/**
 *  Copyright 2013 Gabriel Casarini
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
#import "AlbumControllerTestCase.h"
#import "AlbumData.h"
#import "TrackData.h"
#import "AlbumControllerStub.h"

@implementation AlbumControllerTestCase

#define SERVER_URL @"http://localhost:8080/Muki-demo-server/store"

- (void)testGetAlbum {
	AlbumControllerStub  *stub = [[AlbumControllerStub alloc] initControllerUrl: SERVER_URL];
	
    // Retrieve album from remote server
    NSError *error;
	AlbumData *album = [stub getAlbumId:@"1001"error: &error];
    GHAssertNotNil(album, @"Can't find the album");
    
    // Validate
    NSString *actualTitle = album.title;
    NSString *expectedTitle = @"Muki Collection";
	GHAssertTrue([actualTitle isEqualToString: expectedTitle], @"Expected: %@, but got: %@", expectedTitle, actualTitle);

    long long actualCatalogId = album.catalogId;
    long long expectedCatalogId = 1001;
	GHAssertTrue(actualCatalogId == expectedCatalogId, @"The id is not correct!");
    
    NSString *actualArtist = album.artist;
    NSString *expectedArtist = @"Moka";
	GHAssertTrue([actualArtist isEqualToString: expectedArtist], @"Expected: %@, but got: %@", expectedArtist, actualArtist);
    
    TrackData *mainTrack = album.mainTrack;
	GHAssertNotNil(mainTrack, @"The main track is nil");
    
    NSArray *tracks = album.tracks;
	GHAssertNotNil(tracks, @"The tracks are missing");
    for (TrackData *track in tracks) {
        GHAssertNotNil(track, @"The track is nil");
    }
    
}


@end
