/**
 *  Copyright 2015 Gabriel Casarini
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
#import <UIKit/UIKit.h>
#import <XCTest/XCTest.h>
#import "TrackData.h"
#import "TrackControllerStub.h"

@interface TrackControllerTestCase : XCTestCase

@end

@implementation TrackControllerTestCase

#define SERVER_URL @"http://localhost:8080/Muki-demo-server/store"

- (void)testGetTrack {
    TrackControllerStub  *stub = [[TrackControllerStub alloc] initControllerUrl: SERVER_URL];
    
    // Retrieve track from remote server
    NSError *error;
    TrackData *track = [stub getTrackId:@"3" error:&error];
    XCTAssertNotNil(track, @"Can't find the track!");
    
    // Validate
    NSString *actualTitle = track.title;
    NSString *expectedTitle = @"Muki et moi";
    XCTAssertTrue([actualTitle isEqualToString: expectedTitle], @"Expected: %@, but got: %@", expectedTitle, actualTitle);
    
    long long actualCatalogId = track.catalogId;
    long long expectedCatalogId = 3;
    XCTAssertTrue(actualCatalogId == expectedCatalogId, @"The id is not correct!");
    
    NSInteger actualLength = track.lengthInSeconds;
    NSInteger expectedLength = 220;
    XCTAssertTrue(actualLength == expectedLength, @"The length is not correct!");
    
    double actualPrice = track.price;
    double expectedPrice = 0.79;
    XCTAssertTrue(actualPrice == expectedPrice, @"The price is not correct!");
    
    BOOL actualNewRelease = track.newRelease;
    BOOL expectedNewRelease = YES;
    XCTAssertTrue(actualNewRelease == expectedNewRelease, @"The new release flag is not correct!");
}

- (void)testFindTrackByTitle {
    TrackControllerStub  *stub = [[TrackControllerStub alloc] initControllerUrl: SERVER_URL];
    
    // Retrieve track from remote server
    NSError *error;
    TrackData *track = [stub findTrackByTitleTitle:@"Muki" error:&error];
    
    // Validate
    XCTAssertNotNil(track, @"Can't find the track!");
}

- (void)testAddTrack {
    TrackControllerStub  *stub = [[TrackControllerStub alloc] initControllerUrl: SERVER_URL];
    
    TrackData *newTrack = [[TrackData alloc] init];
    newTrack.title = @"New track";
    newTrack.lengthInSeconds = 247;
    newTrack.price = 1.25;
    newTrack.newRelease = YES;
    newTrack.catalogId = 0;
    
    // Add a new track on the server
    // The operation returns a track with the catalogId assigned by the server
    NSError *error;
    TrackData *addedTrack = [stub addTrack:newTrack error:&error];
    XCTAssertNotNil(addedTrack, @"Error adding track!");
    
    // Validate that the server assigned an ID
    XCTAssertTrue(addedTrack.catalogId > 1, @"The catalogId was not assigned!");
}

- (void)testUpdateTrack {
    TrackControllerStub  *stub = [[TrackControllerStub alloc] initControllerUrl: SERVER_URL];
    
    TrackData *newTrack = [[TrackData alloc] init];
    newTrack.title = @"Title 1";
    newTrack.lengthInSeconds = 247;
    newTrack.price = 1.25;
    newTrack.newRelease = YES;
    newTrack.catalogId = 0;
    
    // Add a new track on the server
    NSError *error;
    newTrack = [stub addTrack:newTrack error:&error];
    XCTAssertNotNil(newTrack, @"Error adding track!");
    
    // Change attributes and update on the server
    newTrack.title = @"Updated title";
    newTrack.lengthInSeconds = 123;
    newTrack.price = 0.75;
    newTrack.newRelease = NO;
    [stub updateTrack:newTrack error:&error];
    
    // Retrieve track from the server
    NSString *idString = [NSString stringWithFormat: @"%lld", newTrack.catalogId];
    TrackData *updatedTrack = [stub getTrackId: idString error:&error];
    XCTAssertNotNil(updatedTrack);
    
    // Validate
    NSString *actualTitle = updatedTrack.title;
    NSString *expectedTitle = @"Updated title";
    XCTAssertTrue([actualTitle isEqualToString: expectedTitle], @"Expected: %@, but got: %@", expectedTitle, actualTitle);
    
    double actualPrice = updatedTrack.price;
    double expectedPrice = 0.75;
    XCTAssertTrue(actualPrice == expectedPrice, @"The price is not correct!");
}

- (void)testDeleteTrack {
    TrackControllerStub  *stub = [[TrackControllerStub alloc] initControllerUrl: SERVER_URL];
    
    // Add a new track
    NSError *error;
    TrackData *newTrack = [[TrackData alloc] init];
    newTrack.title = @"Title 1";
    newTrack.lengthInSeconds = 247;
    newTrack.price = 1.25;
    newTrack.newRelease = YES;
    newTrack.catalogId = 0;
    newTrack = [stub addTrack:newTrack error:&error];
    XCTAssertNotNil(newTrack, @"Error adding track!");
    
    // Retrieve track from remote server
    NSString *idString = [NSString stringWithFormat: @"%lld", newTrack.catalogId];
    TrackData *addedTrack = [stub getTrackId:idString error:&error];
    XCTAssertNotNil(addedTrack, @"Can't find the track!");
    
    // Remove the track
    [stub deleteTrackId:idString error:&error];
    
    // Check that the track is no longer available
    TrackData *deletedTrack = [stub getTrackId:idString error:&error];
    XCTAssertNil(deletedTrack, @"The track should be null");
}

@end
