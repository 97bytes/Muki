/**
 *  Copyright 2015 Gabriel Casarini
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
import UIKit
import XCTest

class TrackControllerTestCase: XCTestCase {

    let SERVICE_URL = "http://localhost:8080/Muki-demo-server/store"
    
    func testGetTrack() {
        let stub = TrackControllerStub(url: SERVICE_URL)
        
        // Retrieve track from remote server
        var localError: NSError?
        let track = stub.getTrack("3", error: &localError)
        XCTAssertNotNil(track)
        
        // Validate
        let actualTitle = track!.title;
        let expectedTitle = "Muki et moi"
        XCTAssertEqual(expectedTitle, actualTitle)
        
        let actualCatalogId = track!.catalogId
        let expectedCatalogId: Int64 = 3
        XCTAssertEqual(expectedCatalogId, actualCatalogId)
        
        let actualLength = track!.lengthInSeconds
        let expectedLength = 220
        XCTAssertEqual(expectedLength, actualLength)
        
        let actualPrice = track!.price
        let expectedPrice = 0.79
        XCTAssertEqual(expectedPrice, actualPrice)
        
        let actualNewRelease = track!.newRelease
        let expectedNewRelease = true
        XCTAssertEqual(expectedNewRelease, actualNewRelease)
    }
    
    func testFindTrackByTitle() {
        let stub = TrackControllerStub(url: SERVICE_URL)
        
        // Retrieve track from remote server
        var localError: NSError?
        let track = stub.findTrackByTitle("Muki", error: &localError)
        
        // Validate
        XCTAssertNotNil(track)
    }
    
    func testAddTrack() {
        let stub = TrackControllerStub(url: SERVICE_URL)
        
        let newTrack = TrackData()
        newTrack.title = "New track"
        newTrack.lengthInSeconds = 247
        newTrack.price = 1.25
        newTrack.newRelease = true
        newTrack.catalogId = 0
        
        // Add a new track on the server
        // The operation returns a track with the catalogId assigned by the server
        var localError: NSError?
        let addedTrack = stub.addTrack(newTrack, error: &localError)
        XCTAssertNotNil(addedTrack)
        
        // Validate
        XCTAssertTrue(addedTrack!.catalogId > 1)
    }
    
    func testUpdateTrack() {
        let stub = TrackControllerStub(url: SERVICE_URL)
        
        var newTrack = TrackData()
        newTrack.title = "Title 1"
        newTrack.lengthInSeconds = 247
        newTrack.price = 1.25
        newTrack.newRelease = true
        newTrack.catalogId = 0
        
        // Add a new track on the server
        var localError: NSError?
        newTrack = stub.addTrack(newTrack, error: &localError)!
        XCTAssertNotNil(newTrack)
        
        // Change attributes and update on the server
        newTrack.title = "Updated title"
        newTrack.lengthInSeconds = 123
        newTrack.price = 0.75
        newTrack.newRelease = false
        stub.updateTrack(newTrack, error: &localError)
        
        // Retrieve track from the server
        let idString = "\(newTrack.catalogId)"
        let updatedTrack = stub.getTrack(idString, error: &localError)
        XCTAssertNotNil(updatedTrack)
        
        // Validate
        let actualTitle = updatedTrack!.title
        let expectedTitle = "Updated title"
        XCTAssertEqual(expectedTitle, actualTitle)
        
        let actualPrice = updatedTrack!.price
        let expectedPrice = 0.75
        XCTAssertEqual(expectedPrice, actualPrice)
    }
    
    func testDeleteTrack() {
        let stub = TrackControllerStub(url: SERVICE_URL)
        
        var newTrack = TrackData()
        newTrack.title = "Title 1"
        newTrack.lengthInSeconds = 247
        newTrack.price = 1.25
        newTrack.newRelease = true
        newTrack.catalogId = 0
        
        // Add a new track on the server
        var localError: NSError?
        newTrack = stub.addTrack(newTrack, error: &localError)!
        XCTAssertNotNil(newTrack)
        
        // Retrieve track from the server
        let idString = "\(newTrack.catalogId)"
        let addedTrack = stub.getTrack(idString, error: &localError)
        XCTAssertNotNil(addedTrack)
        
        // Remove the track
        stub.deleteTrack(idString, error: &localError)
        
        // Check that the track is no longer available
        let deletedTrack = stub.getTrack(idString, error: &localError)
        XCTAssertNil(deletedTrack)
    }
    
}
