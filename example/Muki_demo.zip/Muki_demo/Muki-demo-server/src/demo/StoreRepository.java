/**
 *  Copyright 2013 Gabriel Casarini
 *  
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *  
 *      http://www.apache.org/licenses/LICENSE-2.0
 *  
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package demo;

import java.util.HashMap;
import java.util.Map;

import demo.model.AlbumData;
import demo.model.TrackData;

public class StoreRepository {
	
	private static long TrackId = 1;
	private static long AlbumId = 1001;
	private Map<Long, TrackData> tracks;
	private Map<Long, AlbumData> albums;
	
	public StoreRepository() {
		this.setTracks(new HashMap<Long, TrackData>());
		this.setAlbums(new HashMap<Long, AlbumData>());
		TrackData track1 = this.addTrack(TrackId++, "This is Muki", 400, false, 0.99);
		TrackData track2 = this.addTrack(TrackId++, "Amore Muki", 350, false, 2.99);
		TrackData track3 = this.addTrack(TrackId++, "Muki et moi", 220, true, 0.79);
		TrackData track4 = this.addTrack(TrackId++, "Let's muki", 230, true, 1.00);
		TrackData track5 = this.addTrack(TrackId++, "Muki love", 240, false, 0.99);
		AlbumData album1 = this.addAlbum(AlbumId++, "Muki Collection", "Moka");
		album1.addToTracks(track1);
		album1.addToTracks(track2);
		album1.addToTracks(track3);
		album1.setMainTrack(track1);
		AlbumData album2 = this.addAlbum(AlbumId++, "Muki Hits 2", "Mokki");
		album2.addToTracks(track4);
		album2.addToTracks(track5);
		album2.setMainTrack(track4);
	}
	
	private TrackData addTrack(long catalogId, String title, int seconds, boolean isNewRelease, double price) {
		TrackData track = new TrackData();
		track.setCatalogId(catalogId);
		track.setLengthInSeconds(seconds);
		track.setNewRelease(isNewRelease);
		track.setPrice(price);
		track.setTitle(title);
		this.getTracks().put(catalogId, track);
		return track;
	}
	
	private AlbumData addAlbum(long catalogId, String title, String artist) {
		AlbumData cd = new AlbumData();
		cd.setCatalogId(catalogId);
		cd.setTitle(title);
		cd.setArtist(artist);
		this.getAlbums().put(catalogId, cd);
		return cd;
	}
	
	/**
	 * The catalogId is assigned by this StoreRepository.
	 */
	public void addTrack(TrackData track) {
		track.setCatalogId(TrackId++);
		this.getTracks().put(track.getCatalogId(), track);
	}

	/**
	 * Update attributes instead of replacing the object. This way, the references from the
	 * albums remain unchanged.
	 */
	public void updateTrack(TrackData track) {
		TrackData existingTrack = this.getTrackById(track.getCatalogId());
		existingTrack.setLengthInSeconds(track.getLengthInSeconds());
		existingTrack.setTitle(track.getTitle());
		existingTrack.setPrice(track.getPrice());
		existingTrack.setNewRelease(track.isNewRelease());
	}

	/**
	 * When removing a track, we have to remove all references from the albums too.
	 */
	public void deleteTrack(long catalogId) {
		TrackData track = this.getTrackById(catalogId);
		if (track != null) {
			for (AlbumData album : this.getAlbums().values()) {
				if (album.getTracks().contains(track)) {
					album.getTracks().remove(track);
				}
			}
			this.getTracks().remove(track.getCatalogId());
		}
	}
	
	public TrackData getTrackById(long catalogId) {
		return this.getTracks().get(catalogId);
	}

	public TrackData findTrackByTitle(String title) {
		for (TrackData track : this.getTracks().values()) {
			if (track.getTitle().toLowerCase().indexOf(title.toLowerCase()) > -1) {
				return track;
			}
		}
		return null;
	}

	public AlbumData getAlbumById(long catalogId) {
		return this.getAlbums().get(catalogId);
	}

	private Map<Long, TrackData> getTracks() {
		return tracks;
	}

	private void setTracks(Map<Long, TrackData> tracks) {
		this.tracks = tracks;
	}

	private Map<Long, AlbumData> getAlbums() {
		return albums;
	}

	private void setAlbums(Map<Long, AlbumData> albums) {
		this.albums = albums;
	}


}
